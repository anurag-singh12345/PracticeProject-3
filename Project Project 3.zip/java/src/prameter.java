public class MethodVerification {

    static void greet() {
        System.out.println("Hello! Welcome to Java Methods.");
    }

    
    static int addNumbers(int a, int b) {
        return a + b;
    }

    
    static void printMessage(String message) {
        System.out.println(message);
    }

    public static void main(String[] args) {
    

    
        greet();

        
        int sum = addNumbers(5, 7);
        System.out.println("Sum of numbers: " + sum);
        printMessage("This is a custom message.");

        int result = addNumbers(10, 20);
        System.out.println("Result: " + result);

    
        int x = 15;
        int y = 25;
        int total = addNumbers(x + 5, y - 5);
        System.out.println("Total: " + total);

        int combinedResult = performOperations(x, y);
        System.out.println("Combined Result: " + combinedResult);
    }
    static int performOperations(int a, int b) {
        int sum = addNumbers(a, b);
        printMessage("Performing operations...");
        return sum * 2;
    }
}